class Calculator:
    def add(self, *args):
        return sum(args) 
    def multiply(self, *args):
        result = 1
        for num in args:
            result *= num  
        return result 
    def divide(self, *args):
        result = args[0]  
        for num in args[1:]:
            if num == 0:   
                return "Không thể chia cho 0" 
            result /= num  
        return result  
    def subtract(self, *args):
        result = args[0]  
        for num in args[1:]:
            result -= num 
        return result  
calculator = Calculator()
print(calculator.add(5, 10, 4))           
print(calculator.multiply(1, 2, 3, 5))    
print(calculator.divide(100, 2))          
print(calculator.subtract(90, 20, -50, 43, 7)) \
